---
layout: post
categories: posts
title: Image Post
tags: [sample post]
date-string: NOVEMBER 19, 2016
---
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="_/js/libs/jquery-1.9.1.min.js"><\/script>')</script>

Lorem ipsum dolor sit amet, interdum fermentum arcu, ipsum venenatis curabitur dis. Morbi imperdiet pharetra adipiscing posuere morbi. Aliquam dictum ut nisl wisi quis fermentum, quam lectus amet, eu congue tincidunt. Eget sollicitudin amet lectus at duis vitae, sed id vitae, amet ultricies, eget proin id. Gravida cras consequat, sem elit suscipit, volutpat dui congue, quisque amet ac sit ornare aliquet, sem nec eget felis varius lacus metus. Eros eget viverra habitasse non vitae, fusce euismod commodo pellentesque nonummy sit, ultricies ullamcorper ut neque, egestas sem quisque hendrerit.

<center>
    <div class="photoset-grid-custom" data-layout="213">
        <img src="/images/2016-11-19/abstract-1.jpg">
        <img src="/images/2016-11-19/abstract-2.jpg">
        <img src="/images/2016-11-19/abstract-3.jpg">
        <img src="/images/2016-11-19/abstract-4.jpg">
        <img src="/images/2016-11-19/abstract-5.jpg">
        <img src="/images/2016-11-19/abstract-6.jpg">
    </div>
</center>

 Sit mollis consectetuer tempor in, sociosqu mi in ornare et, placerat in eget ac, praesent pellentesque, mollis est natoque. Quis quis, ac ac pretium sed fusce sollicitudin cursus, magna vitae placerat tincidunt sed dictumst, nullam rutrum pharetra consectetuer. Erat libero odio venenatis, et id ac ultrices convallis, ac iaculis nec vestibulum etiam nec metus, integer velit dictum. Inceptos laoreet at wisi libero dolor, id scelerisque vulputate a amet amet dapibus, at et vitae nec aliquam, fringilla vitae quam. Mauris felis nec sagittis posuere mauris, penatibus ullamcorper, tristique aliquet, vel posuere class placerat. Ornare et non magnis fusce.

<script src="/assets/js/jquery.photoset-grid.js"></script>

<script type="text/javascript">
    $('.photoset-grid-custom').photosetGrid({
    // Set the gutter between columns and rows
    gutter: '5px',
  
    // Wrap the images in links
    highresLinks: true,
  
    // Asign a common rel attribute
    rel: 'print-gallery',

    onInit: function(){},
    
    onComplete: function(){
        // Show the grid after it renders
        $('.photoset-grid-custom').attr('style', '');
    }
});
</script>